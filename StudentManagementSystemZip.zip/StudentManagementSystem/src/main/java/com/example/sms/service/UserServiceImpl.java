package com.example.sms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sms.entity.User;
import com.example.sms.repository.UserRepository;


@Service
public class UserServiceImpl implements UserService {


    @Autowired
    private UserRepository userRepository;


    @Override
    public User saveUser(User user) {

        return userRepository.save(user);
    }


    @Override
    public User findByUsername(String username) {

        return userRepository.findByUsername(username);
    }

}