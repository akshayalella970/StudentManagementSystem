package com.example.sms.service;

import com.example.sms.entity.User;

public interface UserService {

    User saveUser(User user);

    User findByUsername(String username);

}