package com.example.sms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.sms.entity.User;
import com.example.sms.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    // ================= LOGIN PAGE =================

    @GetMapping("/login")
    public String loginPage(Model model, HttpSession session) {

        if (session.getAttribute("username") != null) {
            return "redirect:/";
        }

        model.addAttribute("user", new User());

        return "login";
    }

    // ================= LOGIN =================

    @PostMapping("/login")
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password,
                        HttpSession session,
                        Model model) {

        User user = userService.findByUsername(username);

        if (user == null) {
            model.addAttribute("error", "Invalid Username");
            model.addAttribute("user", new User());
            return "login";
        }

        if (!user.getPassword().equals(password)) {
            model.addAttribute("error", "Invalid Password");
            model.addAttribute("user", new User());
            return "login";
        }

        session.setAttribute("username", username);

        return "redirect:/";
    }

    // ================= SIGNUP PAGE =================

    @GetMapping("/signup")
    public String signupPage(Model model) {

        model.addAttribute("user", new User());

        return "signup";
    }

    // ================= SIGNUP =================

    @PostMapping("/signup")
    public String signup(@ModelAttribute("user") User user,
                         Model model) {

        System.out.println("Username : " + user.getUsername());
        System.out.println("Password : " + user.getPassword());

        User existing = userService.findByUsername(user.getUsername());

        if (existing != null) {

            model.addAttribute("error", "Username already exists");
            return "signup";
        }

        userService.saveUser(user);

        System.out.println("User Saved Successfully");

        return "redirect:/login";
    }

    // ================= LOGOUT =================

    @GetMapping("/logout")
    public String logout(HttpSession session) {

        session.invalidate();

        return "redirect:/login";
    }

}