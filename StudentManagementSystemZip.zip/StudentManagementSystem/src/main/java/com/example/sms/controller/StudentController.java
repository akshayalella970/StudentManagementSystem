package com.example.sms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.sms.entity.Student;
import com.example.sms.service.StudentService;

import jakarta.servlet.http.HttpSession;

@Controller
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/")
    public String viewHomePage(Model model, HttpSession session) {

        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        model.addAttribute("students", studentService.getAllStudents());

        return "index";
    }

    @GetMapping("/showNewStudentForm")
    public String showNewStudentForm(Model model, HttpSession session) {

        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        model.addAttribute("student", new Student());

        return "add-student";
    }

    @PostMapping("/saveStudent")
    public String saveStudent(@ModelAttribute("student") Student student,
                              HttpSession session) {

        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        studentService.saveStudent(student);

        return "redirect:/";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable Long id,
                                    Model model,
                                    HttpSession session) {

        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        Student student = studentService.getStudentById(id);

        model.addAttribute("student", student);

        return "edit-student";
    }

    @PostMapping("/updateStudent")
    public String updateStudent(@ModelAttribute("student") Student student,
                                HttpSession session) {

        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        studentService.updateStudent(student);

        return "redirect:/";
    }

    @GetMapping("/deleteStudent/{id}")
    public String deleteStudent(@PathVariable Long id,
                                HttpSession session) {

        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        studentService.deleteStudentById(id);

        return "redirect:/";
    }
}